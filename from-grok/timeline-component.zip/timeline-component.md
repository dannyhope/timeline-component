# Adaptive Timeline Component Documentation

## Overview
This is a fully responsive, adaptive horizontal timeline component built with pure HTML, CSS, and JavaScript. It supports:

- Dynamic label stacking with collision detection
- Text attachment on either side of hairlines
- Variable label widths based on available space
- Min / max label width controls
- Multiple events on the same day (with small horizontal nudge)
- Compressed period summary when narrow
- Adjustable timeline width (scale)
- Adjustable vertical margin between labels
- Multiple label content modes (Titles / Descriptions / Numbers)

## Features

### Layout & Responsiveness
- **Horizontal axis** with proportional positioning based on dates.
- **Hairlines** connect events to labels (1 px minimum gap enforced).
- **Labels** attach to the left or right of their hairline.
- **Stacking** is fully dynamic and runs in the direction that prevents hairlines from crossing text:
  - Text on right → right-to-left stacking (longer hairlines on left)
  - Text on left → left-to-right stacking (longer hairlines on right)
- **Collision avoidance**: Labels are pushed vertically only when necessary. No unnecessary stacking for short text.

### Controls
- **Descriptions** checkbox — toggles extra description text.
- **Text attaches** dropdown — left or right of the hairline.
- **Timeline width** slider — controls the overall scale (320–1400 px).
- **Text margin** slider — vertical spacing between stacked labels.
- **Min label width** slider — floor for label widths.
- **Max label width** slider — ceiling for label widths (capped at 95vw).

### Compressed Mode
When the timeline is very narrow (< ~520 px usable):
- Individual period labels are hidden.
- A single summary range appears: **12–30 October 1962**.

### Multiple Events on One Day
Events sharing the same day receive a small horizontal offset (3 px per additional event) so their hairlines do not overlap.

## File Structure
- `cuban-missile-crisis-timeline.html` — the complete self-contained component.

## How to Regenerate / Modify
1. Open the HTML file in a browser.
2. Use the controls to tune appearance.
3. Copy the entire `<style>` and `<script>` blocks and the HTML structure.
4. Update the `CONTENT` object in the script for new events/dates.

### Key CSS Variables & Classes
- `--text-reserve` — dynamic space for labels.
- `.label` — main text boxes (z-index, backdrop blur, shadow).
- `.hairline` — vertical connectors.
- `.period-label.summary` — compressed range.

### JavaScript Core Functions
- `setLabelContent()` — updates label text based on checkboxes.
- `measureAndLayout()` — full recalculation of positions, widths, stacking, and reserves.
- `refresh()` — called on any control change or resize.

## Example Data (Cuban Missile Crisis)
```js
const CONTENT = {
  '1': { title: '...', desc: '...', date: '14 October' },
  // ...
};
```

The component is designed to be self-contained and easily adaptable to other timelines by changing the `CONTENT` object and the day values in the HTML events.

---

**Generated on 2026-07-18**  
Ready for reuse or extension. Download this file or copy the full HTML for a standalone version.
